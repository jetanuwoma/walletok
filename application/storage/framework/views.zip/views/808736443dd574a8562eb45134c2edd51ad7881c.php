<div class="ldrs-container">
	<div class="lds-ring"><div></div><div></div><div></div><div></div></div>
</div>