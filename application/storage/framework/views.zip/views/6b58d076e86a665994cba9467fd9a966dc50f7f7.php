<div class="js-cookie-consent cookie-consent text-center text-secondary bg-light p-4">

    <span class="cookie-consent__message">
        <?php echo trans('cookieConsent::texts.message'); ?>

    </span>

    <button class="js-cookie-consent-agree cookie-consent__agree  btn btn-primary ml-5">
        <?php echo e(trans('cookieConsent::texts.agree')); ?>

    </button>

</div>
