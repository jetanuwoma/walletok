<ion-header>
	<ion-toolbar color="primary">
	
	  <ion-buttons slot="start" >
	    <ion-button color="secondary" onclick="openFirst()">
	      <ion-icon slot="icon-only" name="menu"></ion-icon>
	    </ion-button>
	  </ion-buttons>
	  <ion-title color="secondary"><?php echo e($title); ?></ion-title>
	</ion-toolbar>
</ion-header>